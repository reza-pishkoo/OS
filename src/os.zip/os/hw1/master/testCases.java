package os.hw1.master;

public class testCases {
    public static void main(String[] args) {
        System.out.println(

        );
    }
}
